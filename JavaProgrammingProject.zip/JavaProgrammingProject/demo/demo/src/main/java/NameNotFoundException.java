
public class NameNotFoundException extends Exception {

}
