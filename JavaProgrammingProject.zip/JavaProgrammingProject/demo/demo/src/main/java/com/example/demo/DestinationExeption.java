package com.example.demo;

public class DestinationExeption extends Exception {
}
