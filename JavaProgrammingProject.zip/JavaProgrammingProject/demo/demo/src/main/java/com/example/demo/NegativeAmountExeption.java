package com.example.demo;

public class NegativeAmountExeption extends Exception {
}
